#include <stdio.h>
#include "areas.h"
#include "volumenes.h"

int main() {

    float radio, lado;

    printf("=== CALCULADORA GEOMETRICA ===\n");

    printf("\nIngrese el radio del circulo y la esfera: ");
    scanf("%f", &radio);

    printf("Ingrese el lado del cuadrado y cubo: ");
    scanf("%f", &lado);

    printf("\nRESULTADOS\n");

    printf("Area del circulo: %.2f\n", areaCirculo(radio));
    printf("Area del cuadrado: %.2f\n", areaCuadrado(lado));

    printf("Volumen de la esfera: %.2f\n", volumenEsfera(radio));
    printf("Volumen del cubo: %.2f\n", volumenCubo(lado));

    return 0;
}